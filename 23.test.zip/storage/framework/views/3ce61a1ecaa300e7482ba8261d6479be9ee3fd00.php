<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=no,
    width=device-width,initial-scale=1.0" />
    <meta property="lang" content="en"/>
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>"  rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>"  rel="stylesheet" type="text/css"/>
</head>
<body style="padding: 0px">
<div class="min-h-screen flex flex-col  items-center default-bg">
    <div class="login-box">
        <!-- 登录表单 -->
        <form method="POST"  action="<?php echo e(route('authenticate')); ?>" id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="text-align: center;">
                <input type="text" class="form-control" id="user_id"
                       style="display:inline;width:200px;" autocomplete="off" name="user_id"
                       placeholder="User-Id"/>
                <div>
                    <?php $__errorArgs = ['user_id_msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong style="color: red"><?php echo e($message); ?></strong>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group" style="text-align: center;">
                <input type="password" class="form-control" id="password"
                       style="display:inline;width:200px;" autocomplete="off" name="password"
                       placeholder="Password"/>
                <div>
                    <?php $__errorArgs = ['password_msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong style="color: red"><?php echo e($message); ?></strong>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group" style="text-align: center">
                <button type="submit" class="login-bt_yellow btn" STYLE="color: #1a1e24" onclick="lsRememberMe()" value="Login">LOGIN</button>
            </div>
        </form>
    </div>

</div>

</body>
</html>
<script src="<?php echo e(asset('assets/js/jquery/jquery-1.11.1.min.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>" ></script>
<script>
    function lsRememberMe() {
        $('#loginForm').submit();
    }
</script>
<?php /**PATH D:\phpstudy_pro\WWW\23.test\resources\views/login.blade.php ENDPATH**/ ?>
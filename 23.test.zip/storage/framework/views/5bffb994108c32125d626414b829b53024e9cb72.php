<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-box">
                        <div>
                            <div class="dropdown float-right">
                                <button type="button" class="btn btn-xs width-xs btn-warning  waves-light"
                                        onclick="salesInput()">
                                    Sales Input
                                </button>
                                <button type="button" class="btn btn-xs width-xs btn-info waves-light"
                                        onclick="inbox()">Inbox
                                </button>
                            </div>
                            <div>
                                <h4 class="mt-0 header-title">
                                    <i class="mdi mdi-access-point"></i>
                                    <span> Administration </span></h4>
                                <div>
                                    <span class="title  pt-md-2">1.Reset Password</span>
                                    <div class="dropdown">
                                        <form role="form" class="form-horizontal">
                                            <label class="col-form-label">User-Id</label>
                                            <div class="autosuggest-container">
                                                <input type="text" class="form-control">
                                            </div>
                                            <label class="col-form-label">Reset Password</label>
                                            <div class="autosuggest-container">
                                                <input type="text" class="form-control">
                                            </div>
                                            <div class="col-form-label">
                                                <button type="button"
                                                        class="btn btn-xs width-xs btn-info waves-light">
                                                    Confirm
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <div>
                                    <span>2.Confirm Create User Account</span>
                                    <div class="dropdown">
                                        <div class="dropdown float-right">
                                            <button type="button"
                                                    class="btn btn-xs width-xs btn-warning  waves-light"
                                                    @click="reset()">
                                                Reset
                                            </button>
                                            <button type="button" class="btn btn-xs width-xs btn-info waves-light"
                                                    @click="search()">Search
                                            </button>
                                        </div>
                                        <form role="form" class="form-horizontal">
                                            <label class="col-form-label">Search</label>
                                            <div class="autosuggest-container">
                                                <div id="autosuggest">
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="input-container">
                                                <label for="example-date" class="col-form-label">From</label>
                                                <input id="from-date" type="date" name="date" class="form-control">
                                            </div>
                                            <div class="input-container">
                                                <div class="form-group">
                                                    <label for="example-date" class="col-form-label">To</label>
                                                    <input id="example-date" type="date" name="date"
                                                           class="form-control">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                <tr>
                                    <th>Date</th>
                                    <th>User-Id</th>
                                    <th>Name</th>
                                    <th>Select</th>
                                    <th>NDA</th>
                                    <th>Confirm</th>
                                    <th>Option</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-cloak>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td class="button-list">
                                        <button class="btn btn-warning waves-light btn-sm">Add</button>
                                    </td>
                                </tr>
                                </tbody>
                            </table> <!----></div>
                    </div>
                </div>
            </div>
        </div>
        <div id="salesInput" class="demo-modal">
            <a href="javascript:void(0);" onclick="Custombox.modal.close();" class="demo-close"><i
                    class="mdi mdi-close"></i></a>
            <form role="form" class="form-horizontal">
                <div class="input-container">
                    <label class="col-form-label">User-Id</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Time</label>
                    <input type="time" name="date" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Clinet Name</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Agent-Id</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Direct-Comm</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Referrer-Comm</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Bonus</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Loyalty</label>
                    <input type="text" class="form-control">
                </div>
                <div class="float-center" style="text-align: center;margin-top: 10px;">
                    <button type="button"
                            class="btn  width-xs btn-info waves-light  btn-small">Confirm
                    </button>
                </div>
            </form>
        </div>
        <div id="inbox" class="demo-modal">
            <a href="javascript:void(0);" onclick="Custombox.modal.close();" class="demo-close"><i
                    class="mdi mdi-close"></i></a>
            <form role="form" class="form-horizontal">
                <div class="input-container">
                    <label class="col-form-label">User-Id</label>
                    <input type="text" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Data</label>
                    <input type="date" name="date" class="form-control">
                </div>
                <div class="input-container">
                    <label class="col-form-label">Message</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        new Vue({
            el: "#app",
            data: {},
            methods: {
                demo: function () {
                    let that = this;
                    $.ajax({
                        url: "",
                        type: 'get',
                        data: {},
                        dataType: 'json',
                        success: function (res) {
                        }
                    })
                }
            },
            created() {
            }

        })
        function salesInput() {
            let modal = new Custombox.modal({
                content: {
                    effect: 'fadein',
                    target: '#salesInput'
                }
            });
            modal.open();
        }

        function inbox() {
            let modal = new Custombox.modal({
                content: {
                    effect: 'fadein',
                    target: '#inbox'
                }
            });
            modal.open();
        }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\23.test\resources\views////administration.blade.php ENDPATH**/ ?>